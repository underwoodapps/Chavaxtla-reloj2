package com.chavaxtla.reloj;

import android.app.Presentation;
import android.content.Context;
import android.graphics.Color;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;
import android.webkit.WebSettings;
import android.webkit.WebView;

/**
 * Fondo de pantalla animado: muestra el HTML (assets/index.html) con un WebView
 * dibujado directamente sobre la superficie del fondo mediante una pantalla virtual.
 */
public class RelojWallpaperService extends WallpaperService {

    @Override
    public Engine onCreateEngine() {
        return new RelojEngine();
    }

    private class RelojEngine extends Engine {
        private VirtualDisplay display;
        private Presentation presentation;
        private WebView web;

        @Override
        public void onCreate(SurfaceHolder surfaceHolder) {
            super.onCreate(surfaceHolder);
            setTouchEventsEnabled(false);
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            liberar();
            try {
                DisplayManager dm = (DisplayManager) getSystemService(Context.DISPLAY_SERVICE);
                int dpi = getResources().getDisplayMetrics().densityDpi;
                display = dm.createVirtualDisplay("ChavaxtlaReloj", width, height, dpi,
                        holder.getSurface(), 0);

                presentation = new Presentation(RelojWallpaperService.this, display.getDisplay());
                web = new WebView(presentation.getContext());
                WebSettings s = web.getSettings();
                s.setJavaScriptEnabled(true);
                s.setDomStorageEnabled(true);
                s.setAllowFileAccess(true);
                web.setBackgroundColor(Color.BLACK);
                web.setVerticalScrollBarEnabled(false);
                web.setHorizontalScrollBarEnabled(false);
                presentation.setContentView(web);
                presentation.show();
                web.addJavascriptInterface(new Ubicacion(RelojWallpaperService.this), "Android");
                web.loadUrl("file:///android_asset/index.html");
                if (!isVisible()) web.onPause();
            } catch (Exception e) {
                liberar();
            }
        }

        @Override
        public void onVisibilityChanged(boolean visible) {
            super.onVisibilityChanged(visible);
            if (web == null) return;
            if (visible) {
                web.onResume();
                web.resumeTimers();
            } else {
                web.onPause();   // pausa solo mientras no se ve, para no gastar batería de más
            }
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            liberar();
            super.onSurfaceDestroyed(holder);
        }

        @Override
        public void onDestroy() {
            liberar();
            super.onDestroy();
        }

        private void liberar() {
            if (web != null) {
                try { web.stopLoading(); web.destroy(); } catch (Exception ignored) { }
                web = null;
            }
            if (presentation != null) {
                try { presentation.dismiss(); } catch (Exception ignored) { }
                presentation = null;
            }
            if (display != null) {
                display.release();
                display = null;
            }
        }
    }
}
