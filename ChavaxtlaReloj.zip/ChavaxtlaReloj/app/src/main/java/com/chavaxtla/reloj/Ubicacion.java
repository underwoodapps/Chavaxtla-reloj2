package com.chavaxtla.reloj;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.webkit.JavascriptInterface;

/** Le pasa al HTML la última ubicación conocida del teléfono ("lat,lon" o vacío). */
public class Ubicacion {
    private final Context ctx;
    public Ubicacion(Context ctx) { this.ctx = ctx.getApplicationContext(); }

    @JavascriptInterface
    public String getUbicacion() {
        try {
            if (ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                return "";
            LocationManager lm = (LocationManager) ctx.getSystemService(Context.LOCATION_SERVICE);
            Location mejor = null;
            for (String prov : lm.getProviders(true)) {
                Location l = lm.getLastKnownLocation(prov);
                if (l != null && (mejor == null || l.getTime() > mejor.getTime())) mejor = l;
            }
            return mejor == null ? "" : mejor.getLatitude() + "," + mejor.getLongitude();
        } catch (Exception e) { return ""; }
    }
}
